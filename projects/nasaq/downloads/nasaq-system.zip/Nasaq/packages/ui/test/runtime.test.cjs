const {test}=require('node:test'),assert=require('node:assert/strict');
const api=require('../lib/index.cjs');
test('SSR import, typed token graph and clone isolation',async()=>{
 assert.equal(typeof api.initNasaq(),'function');
 assert.equal(api.tokenNames.length,340);
 assert.equal(api.getToken('interaction.reveal.duration').value,320);
 assert.equal(api.getToken('type-en.body-md').fontFamily[0],'Inter');
 assert.equal(api.getToken('type.body-md').fontFamily[0],'Almarai');
 const value=api.getToken('type-en.body-md');value.fontFamily[0]='mutated';assert.equal(api.getToken('type-en.body-md').fontFamily[0],'Inter');
 assert.throws(()=>api.getToken('missing'),RangeError);
 for(const name of api.tokenNames)api.getToken(name);
 const esm=await import('../lib/index.js');assert.deepEqual(esm.getToken('type-en.body-md'),api.getToken('type-en.body-md'));
});
function fixture(direction='ltr'){
 const listeners=new Map(),panels=new Map();
 const doc={nodeType:9,defaultView:{getComputedStyle:()=>({direction})},getElementById:id=>panels.get(id),querySelectorAll:()=>[],addEventListener(name,fn){if(!listeners.has(name))listeners.set(name,new Set());listeners.get(name).add(fn)},removeEventListener(name,fn){listeners.get(name).delete(fn)}};
 const fire=(name,target,key)=>{const event={target,key,preventDefault(){this.prevented=true}};for(const fn of listeners.get(name)||[])fn(event);return event};
 const tabs=[0,1,2].map(i=>({disabled:i===1,attrs:{'aria-controls':'panel'+i},tabIndex:i===0?0:-1,focused:false,getAttribute(k){return this.attrs[k]},setAttribute(k,v){this.attrs[k]=v},focus(){this.focused=true},closest(s){if(s==='[role="tab"]')return this;if(s==='[role="tablist"]')return list;if(s==='[data-tabs]')return group;return null}}));
 const list={querySelectorAll:()=>tabs},group={querySelectorAll:()=>tabs};tabs.forEach((_,i)=>panels.set('panel'+i,{hidden:i!==0}));
 return {doc,fire,tabs,listeners,panels};
}
test('LTR and RTL arrow keys skip disabled tabs and update linked panels',()=>{
 for(const [direction,key]of [['ltr','ArrowRight'],['rtl','ArrowLeft']]){
  const f=fixture(direction),cleanup=api.initNasaq(f.doc);assert.equal(api.initNasaq(f.doc),cleanup);
  assert(f.fire('keydown',f.tabs[0],key).prevented);assert(f.tabs[2].focused);assert.equal(f.tabs[2].attrs['aria-selected'],'true');assert.equal(f.panels.get('panel2').hidden,false);assert.equal(f.panels.get('panel0').hidden,true);
  f.fire('keydown',f.tabs[2],'Home');assert.equal(f.tabs[0].attrs['aria-selected'],'true');
  cleanup();assert.equal(f.listeners.get('keydown').size,0);const next=api.initNasaq(f.doc);cleanup();assert.equal(f.listeners.get('keydown').size,1);next();
 }
});
test('subtree does not open dialogs outside its root, and cleanup removes handlers',()=>{
 const f=fixture(),outside={tagName:'DIALOG',open:false,showModal(){this.open=true}};f.panels.set('outside',outside);
 const root={ownerDocument:f.doc,contains:el=>el!==outside,querySelectorAll:()=>[],addEventListener:f.doc.addEventListener.bind(f.doc),removeEventListener:f.doc.removeEventListener.bind(f.doc)};
 const opener={dataset:{open:'outside'},getAttribute:()=>null,closest(s){return s==='[data-open]'?this:null}};
 const cleanup=api.initNasaq(root);f.fire('click',opener);assert.equal(outside.open,false);cleanup();assert.equal(f.listeners.get('click').size,0);
});
test('dialog trigger and close use native methods and restore focus',()=>{
 const f=fixture();const opener={dataset:{open:'dialog'},isConnected:true,focused:false,getAttribute:()=>null,focus(){this.focused=true},closest(s){return s==='[data-open]'?this:null}};
 const closer={dataset:{close:'dialog'},getAttribute:()=>null,closest(s){return s==='[data-close]'?this:null}};
 const dialog={tagName:'DIALOG',open:false,showModal(){this.open=true},close(){this.open=false;f.fire('close',this)}};f.panels.set('dialog',dialog);
 const cleanup=api.initNasaq(f.doc);f.fire('click',opener);assert(dialog.open);f.fire('click',closer);assert.equal(dialog.open,false);assert(opener.focused);cleanup();
});
