const activeRoots = new WeakMap();
/** Attach delegated native interactions. Call the returned function on unmount. */
function initNasaq(root = typeof document === 'undefined' ? undefined : document) {
  if (!root) return () => {};
  if (activeRoots.has(root)) return activeRoots.get(root);
  const doc = root.nodeType === 9 ? root : root.ownerDocument;
  if (!doc || typeof root.addEventListener !== 'function') throw new TypeError('Expected a Document or HTMLElement');
  const within = el => !!el && (root === doc || root.contains(el));
  const target = event => event.target?.closest ? event.target : null;
  const find = id => { const el = doc.getElementById(id); return within(el) ? el : null; };
  const disabled = el => el.disabled || el.getAttribute('aria-disabled') === 'true';
  const activate = tab => {
    const group = tab.closest('[data-tabs]');
    if (!within(group) || disabled(tab)) return;
    group.querySelectorAll('[role="tab"]').forEach(item => {
      const selected = item === tab;
      item.setAttribute('aria-selected', String(selected));
      item.tabIndex = selected ? 0 : -1;
      const panel = find(item.getAttribute('aria-controls'));
      if (panel) panel.hidden = !selected;
    });
  };
  const dialogFocus = new WeakMap();
  const restore = dialog => {
    const trigger = dialogFocus.get(dialog);
    dialogFocus.delete(dialog);
    if (trigger?.isConnected && typeof trigger.focus === 'function') trigger.focus();
  };
  const click = event => {
    const el = target(event); if (!el) return;
    const opener = el.closest('[data-open]');
    if (within(opener) && !disabled(opener)) {
      const dialog = find(opener.dataset.open);
      if (dialog?.tagName === 'DIALOG' && typeof dialog.showModal === 'function' && !dialog.open) {
        dialogFocus.set(dialog, opener); dialog.showModal();
      }
    }
    const closer = el.closest('[data-close]');
    if (within(closer) && !disabled(closer)) {
      const dialog = find(closer.dataset.close);
      if (dialog?.tagName === 'DIALOG' && dialog.open) dialog.close();
    }
    const tab = el.closest('[role="tab"]'); if (within(tab)) activate(tab);
  };
  const keydown = event => {
    const el = target(event); if (!el) return;
    const tab = el.closest('[role="tab"]');
    if (within(tab) && !disabled(tab) && ['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) {
      const list = tab.closest('[role="tablist"]');
      if (!within(list) || !within(tab.closest('[data-tabs]'))) return;
      const tabs = [...list.querySelectorAll('[role="tab"]')].filter(t => !disabled(t));
      if (!tabs.length) return;
      const rtl = doc.defaultView?.getComputedStyle(tab).direction === 'rtl';
      let i = tabs.indexOf(tab);
      if (event.key === 'Home') i = 0;
      else if (event.key === 'End') i = tabs.length - 1;
      else i = (i + (event.key === 'ArrowLeft' ? (rtl ? 1 : -1) : (rtl ? -1 : 1)) + tabs.length) % tabs.length;
      event.preventDefault(); activate(tabs[i]); tabs[i].focus();
    }
    if (event.key === 'Escape') root.querySelectorAll('.nq-tooltip').forEach(t => { t.style.visibility = 'hidden'; });
  };
  const tooltip = (event, visible) => {
    const wrap = target(event)?.closest('.nq-tooltip-wrap');
    if (!within(wrap)) return;
    if (event.relatedTarget && wrap.contains(event.relatedTarget)) return;
    const tip = wrap.querySelector('.nq-tooltip');
    if (tip) tip.style.visibility = visible ? 'visible' : 'hidden';
  };
  const listeners = [
    ['click', click], ['keydown', keydown], ['close', e => { if (e.target?.tagName === 'DIALOG') restore(e.target); }, true],
    ['focusin', e => tooltip(e, true)], ['focusout', e => tooltip(e, false)],
    ['pointerover', e => tooltip(e, true)], ['pointerout', e => tooltip(e, false)]
  ];
  listeners.forEach(([name, handler, capture = false]) => root.addEventListener(name, handler, capture));
  let disposed = false;
  const cleanup = () => {
    if (disposed) return;
    disposed = true;
    listeners.forEach(([name, handler, capture = false]) => root.removeEventListener(name, handler, capture));
    root.querySelectorAll('.nq-tooltip').forEach(t => { t.style.visibility = ''; });
    activeRoots.delete(root);
  };
  activeRoots.set(root, cleanup);
  return cleanup;
}
function getToken(name) {
  const token = name.split('.').reduce((node, key) => node && Object.hasOwn(node, key) ? node[key] : undefined, tokens);
  if (!token || !Object.hasOwn(token, '$value')) throw new RangeError(`Unknown Nasaq token: ${name}`);
  const resolve = (value, seen) => {
    if (typeof value === 'string' && /^\{[^{}]+\}$/.test(value)) {
      const ref = value.slice(1, -1);
      if (seen.has(ref)) throw new Error(`Cyclic token reference: ${ref}`);
      const next = ref.split('.').reduce((node, key) => node && Object.hasOwn(node, key) ? node[key] : undefined, tokens);
      if (!next || !Object.hasOwn(next, '$value')) throw new RangeError(`Unknown token reference: ${ref}`);
      return resolve(next.$value, new Set([...seen, ref]));
    }
    if (Array.isArray(value)) return value.map(v => resolve(v, seen));
    if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([key, v]) => [key, resolve(v, seen)]));
    return value;
  };
  return resolve(token.$value, new Set([name]));
}
