#!/usr/bin/env python3
"""Verify generated docs, asset links, token graphs, packages and MCP protocol."""
from pathlib import Path
from html.parser import HTMLParser
import json,re,subprocess,tempfile,zipfile
from urllib.parse import unquote,urlsplit
R=Path(__file__).resolve().parents[1];D=R/'dist';DL=D/'downloads'
for p in (D/'assets/code-editor.js',D/'assets/case.js',D/'assets/exploration-content.js',D/'assets/exploration-runtime.js',D/'assets/foundation-content.js',D/'assets/foundation-runtime.js',D/'assets/icon-studio.js',D/'assets/editorial-content.js',D/'assets/artwork-content.js',D/'assets/editorial-runtime.js',D/'assets/workflow.js',D/'assets/onboarding.js',D/'assets/docs-en.js',D/'assets/docs-en-content.js',D/'assets/components-en-data.js',DL/'motion-en-examples.js',D/'assets/docs.js',D/'assets/nasaq.js',D/'assets/tokens-data.js',DL/'examples.js',D/'assets/icons-data.js',DL/'motion-examples.js'):
 subprocess.run(['node','--check',str(p)],check=True)
with tempfile.TemporaryDirectory() as tmp:
 renderfile=Path(tmp)/'pages.json'
 subprocess.run(['node',str(R/'scripts/render-check.cjs'),str(renderfile)],check=True)
 rendered=json.loads(renderfile.read_text())
 routes=set(rendered)
 class Check(HTMLParser):
  def __init__(self,base):super().__init__();self.base=base;self.ids=[];self.links=[]
  def handle_starttag(self,tag,attrs):
   a=dict(attrs)
   if 'id' in a:self.ids.append(a['id'])
   for k in ('src','href'):
    if k in a:self.links.append(a[k])
  def check(self):
   assert len(self.ids)==len(set(self.ids)),(self.base,'duplicate ids')
   for link in self.links:
    u=urlsplit(link)
    if u.scheme or link.startswith('//'):continue
    if u.path:
     target=(R.parent/'ISMUX/public'/unquote(u.path).lstrip('/')) if u.path.startswith('/') else self.base/unquote(u.path)
     assert target.resolve().exists(),(self.base,link)
    elif u.fragment and self.base==D:assert u.fragment in self.ids or u.fragment in routes or u.fragment=='main',link
 enfile=Path(tmp)/'english.json'
 subprocess.run(['node',str(R/'scripts/build_english.cjs'),str(enfile)],check=True)
 english=json.loads(enfile.read_text())
 assert set(english)==routes
 encat=json.loads((DL/'mcp/catalog.en.json').read_text())
 arcat=json.loads((DL/'mcp/catalog.json').read_text())
 assert set(encat['components'])==set(arcat['components'])
 assert set(encat['patterns'])==set(arcat['patterns'])
 assert not re.search('[\u0600-\u06ff]',json.dumps(encat['components'],ensure_ascii=False))
 for id,html in english.items():
  assert '<h1>' in html and 'undefined' not in html,id
  c=Check(D);c.feed(html);c.check()
 for id,html in rendered.items():
  c=Check(D);c.feed(html);c.check()
 for p in D.rglob('*.html'):
  c=Check(p.parent);c.feed(p.read_text());c.check()
 for p in D.rglob('*.css'):
  for link in re.findall(r'url\([\'"]?([^\)\'\"]+)',p.read_text()):
   if not urlsplit(link).scheme:assert (p.parent/link).exists(),(p,link)
cat=json.loads((DL/'mcp/catalog.json').read_text());assert len(cat['components'])==18 and len(cat['patterns'])==12
assert all(len(c['states'])>=3 for c in cat['components'].values())
assert len(list((D/'assets').glob('misc-*.svg')))==16
flat={}
def flatten(node,prefix=''):
 for k,v in node.items():
  if k.startswith('$'):continue
  name=prefix+'.'+k if prefix else k
  if isinstance(v,dict) and '$value' in v:flat[name]=v
  elif isinstance(v,dict):flatten(v,name)
flatten(json.loads((DL/'tokens.json').read_text()))
def resolve(name,trail=()):
 assert name not in trail and name in flat,name
 t=flat[name]
 def value(v):
  if isinstance(v,str) and v.startswith('{'):
   ref=v[1:-1];return resolve(ref,trail+(name,))
  if isinstance(v,dict):return {k:value(x) for k,x in v.items()}
  if isinstance(v,list):return [value(x) for x in v]
  return v
 return value(t['$value'])
for name in flat:resolve(name)
assert len(flat)==340
assert len(cat['assets'])>=2130
assert len(list((D/'assets/lucide').glob('*.svg')))==2130
assert (D/'assets/lucide/LICENSE').is_file()
assert 'hero-main' not in rendered['overview']
assert '<section class="cover">' not in (D/'case-study.html').read_text()
assert 'motion' in rendered and 'motion.duration.slow' in flat and flat['type.body-md']['$type']=='typography'
css=(DL/'nasaq.css').read_text();defined=set(re.findall(r'(--nq-[\w-]+)\s*:',css));used=set(re.findall(r'var\((--nq-[\w-]+)',css));assert not used-defined,used-defined
assert not re.search(r'(--nq-[\w-]+):var\(\1\)',css),'Self-referential generated CSS alias'
# Foreground/background contrast pairs used in fixed marketing panels and semantic UI.
def luminance(h):
 v=[int(h[i:i+2],16)/255 for i in (1,3,5)];v=[n/12.92 if n<=.04045 else ((n+.055)/1.055)**2.4 for n in v];return sum(a*b for a,b in zip(v,(.2126,.7152,.0722)))
def contrast(a,b):
 x,y=sorted((luminance(a),luminance(b)));return (y+.05)/(x+.05)
for fg,bg in [('#FFFFFF','#1D4ED8'),('#F3F5F8','#151A22'),('#18202B','#F4F6F8'),('#566171','#F4F6F8'),('#173FAE','#E9EFFF'),('#EDF1F7','#1B2028'),('#10214B','#8EB2FF')]:assert contrast(fg,bg)>=4.5,(fg,bg)
# 1.5 semantic text, action, focus, control-boundary and progress pairs in both modes.
for mode in ('light','dark'):
 def h(role):return resolve('semantic.'+mode+'.'+role)['hex']
 pairs=[('text',bg,4.5) for bg in ('background','surface','surface-subtle','surface-hover','surface-pressed')]
 pairs += [('muted',bg,4.5) for bg in ('background','surface','surface-subtle')]
 pairs += [('on-action',bg,4.5) for bg in ('action','action-hover','action-pressed')]
 pairs += [('on-selected','selected',4.5),('focus','background',3),('focus','surface',3),('border-strong','surface',3),('border-strong','background',3),('action','track',3)]
 pairs += [(role,bg,4.5) for role in ('link','error','success','info') for bg in ('background','surface')]
 pairs += [('on-inverse','inverse',4.5),('inverse-muted','inverse',4.5),('on-inverse','inverse-selected',4.5),('inverse-accent','inverse',3)]
 for fg,bg,minimum in pairs:assert contrast(h(fg),h(bg))>=minimum,(mode,fg,bg,contrast(h(fg),h(bg)))
 assert len({h(role) for role in ('surface','surface-hover','surface-pressed')})==3
for key,t in flat.items():
 if key.startswith('shade.'):
  bg=t['$value']['hex']; fg='#171717' if contrast('#171717',bg)>=4.5 else '#FFFFFF' if contrast('#FFFFFF',bg)>=4.5 else '#000000'
  assert contrast(fg,bg)>=4.5,(key,fg,bg)
subprocess.run(['node',str(R/'scripts/interaction-check.cjs')],check=True)
subprocess.run(['node',str(R/'scripts/experience-check.cjs')],check=True)
subprocess.run(['python3',str(DL/'mcp/test_server.py')],check=True)
subprocess.run(['node','--test',str(R/'packages/ui/test/runtime.test.cjs')],check=True)
subprocess.run(['python3',str(R/'scripts/verify_npm.py')],check=True)
for p in DL.glob('*.zip'):
 with zipfile.ZipFile(p) as z:assert z.testzip() is None,p
# Portable font/license copies and CSS are synchronized.
assert (D/'assets/nasaq.css').read_text()==css.replace('assets/fonts.css','fonts.css')
for name in ['nasaq.css','fonts.css','tokens.json']:
 src=DL/name if name!='fonts.css' else D/'assets/fonts.css'
 skill=DL/'nasaq-ui/assets'/name
 assert src.read_bytes()==skill.read_bytes() if name!='nasaq.css' else (D/'assets/nasaq.css').read_bytes()==skill.read_bytes()
report={'version':'1.5.0','routes':len(routes),'englishRoutes':len(english),'components':18,'stateSpecimens':sum(len(c['states']) for c in cat['components'].values()),'patterns':12,'miscSymbols':16,'utilityIcons':len(list((D/'assets').glob('icon-*.svg'))),'typedTokens':len(flat),'lucideIcons':2130,'colorShades':88,'typographyStyles':38,'languages':['ar','en'],'npm':json.loads((DL/'npm-package.json').read_text()),'mcp':'39 subprocess protocol exchanges passed','verification':['JS syntax',str(len(routes))+' routes per language','HTML local assets and unique ids','CSS font paths and aliases','typed token resolution','semantic contrast pairs and all 88 shade labels','icon filtering and motion state transitions','20 bilingual onboarding destinations and workflow recovery contracts','ZIP integrity','portable copies','npm tarball installation, ESM/CommonJS, SSR, native lifecycle and Vite production build'],'browserReview':['See outputs/nasaq-1.5/browser/browser-results.json for the 1.5 browser regression results and associated screenshots.'],'browserReviewLimitations':['Automated browser checks and representative screenshot inspection do not establish a human accessibility or language audit.']}
(R/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
print('Passed: docs, token graph, assets, packages and MCP. '+str(report['stateSpecimens'])+' visible component state specimens.')
