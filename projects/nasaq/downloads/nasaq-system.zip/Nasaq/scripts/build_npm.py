#!/usr/bin/env python3
"""Generate the npm distribution from the canonical Nasaq files and pack it locally."""
from pathlib import Path
import json, shutil, subprocess, os
R=Path(__file__).resolve().parents[1]; D=R/'dist'; DL=D/'downloads'; P=R/'packages/ui'
for name in ('lib','styles','assets'):(P/name).mkdir(parents=True,exist_ok=True)
shutil.copytree(D/'assets/lucide',P/'assets/lucide',dirs_exist_ok=True)
for p in (D/'assets').iterdir():
 if p.suffix in ('.ttf','.svg') or p.name in ('fonts.css','almarai-OFL.txt','inter-OFL.txt'):shutil.copy2(p,P/'assets'/p.name)
(P/'styles/nasaq.css').write_text((DL/'nasaq.css').read_text().replace('assets/fonts.css','../assets/fonts.css'))
tokens=json.loads((DL/'tokens.json').read_text());names=[]
def walk(node,prefix=''):
 for key,value in node.items():
  if key.startswith('$'):continue
  name=prefix+key
  if isinstance(value,dict) and '$value' in value:names.append(name)
  elif isinstance(value,dict):walk(value,name+'.')
walk(tokens)
shutil.copy2(DL/'tokens.json',P/'tokens.json')
cat=json.loads((DL/'mcp/catalog.json').read_text())
for name in ('components','patterns'):(P/(name+'.json')).write_text(json.dumps(cat[name],ensure_ascii=False,indent=2)+'\n')
cat_en=json.loads((DL/'mcp/catalog.en.json').read_text())
for name in ('components','patterns'):(P/(name+'.en.json')).write_text(json.dumps(cat_en[name],ensure_ascii=False,indent=2)+'\n')
(P/'assets/brand').mkdir(exist_ok=True)
for p in (DL/'brand-kit').glob('*.svg'):
 (P/'assets/brand'/p.name).write_text(p.read_text().replace('url(inter-variable.ttf)','url(../inter-variable.ttf)'))
version=json.loads((P/'package.json').read_text())['version']
base='const version='+json.dumps(version)+';\nconst tokens='+json.dumps(tokens,ensure_ascii=False)+';\nconst tokenNames='+json.dumps(names)+';\n'+(P/'src/runtime.js').read_text()
(P/'lib/index.js').write_text(base+'\nexport {version,tokens,tokenNames,getToken,initNasaq};\n')
(P/'lib/index.cjs').write_text("'use strict';\n"+base+'\nmodule.exports={version,tokens,tokenNames,getToken,initNasaq};\n')
types='''/** DTCG token values; getToken resolves references recursively. */
export type TokenValue = string | number | boolean | null | TokenValue[] | { [key: string]: TokenValue };
export interface DesignToken { $type: string; $value: TokenValue; $description?: string; }
export interface TokenGroup { [key: string]: TokenGroup | DesignToken; }
export type TokenName = '''+' | '.join(json.dumps(n) for n in names)+''';
export declare const version: string;
export declare const tokens: TokenGroup;
export declare const tokenNames: readonly TokenName[];
export declare function getToken(name: TokenName): TokenValue;
/** SSR-safe. Call once per Document or subtree; call cleanup on unmount. Avoid overlapping roots. */
export declare function initNasaq(root?: Document | HTMLElement): () => void;
'''
for name in ('index.d.ts','index.d.cts'):(P/'lib'/name).write_text(types)
# No publish, network fetch, dependency installation or lifecycle scripts.
env=dict(os.environ,NPM_CONFIG_CACHE='/private/tmp/nasaq-npm-cache',NPM_CONFIG_UPDATE_NOTIFIER='false')
result=subprocess.run(['npm','pack','--ignore-scripts','--offline','--json','--pack-destination',str(DL)],cwd=P,env=env,check=True,capture_output=True,text=True)
meta=json.loads(result.stdout)[0]
# Scoped package metadata can retain the scope separator in some npm versions.
# The downloadable filename must point at the actual packed archive.
packed_name=meta['name'].lstrip('@').replace('/','-')+'-'+meta['version']+'.tgz'
if (DL/packed_name).is_file():meta['filename']=packed_name
assert (DL/meta['filename']).is_file(),meta['filename']
(DL/'npm-package.json').write_text(json.dumps({k:meta[k] for k in ('name','version','filename','size','unpackedSize','shasum','integrity','entryCount')},indent=2)+'\n')
print('Packed '+meta['filename']+' — '+str(meta['entryCount'])+' files, no runtime dependencies.')
