#!/usr/bin/env python3
"""Record the current source and browser evidence without reusing an older release's QA claims."""
from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parents[1];D=R/'dist';O=R.parent/'outputs/nasaq-1.5'
release=json.loads((R/'release.json').read_text())
verification=json.loads((R/'verification.json').read_text())
assert verification['version']==release['version']
browser=json.loads((O/'browser/browser-results.json').read_text())
assert not browser['errors'] and len(browser['checks'])==16
checks=[{'name':name,'status':'passed'} for name in verification['verification']]
checks.append({'name':'752 route / language / viewport / theme combinations and native interaction checks','status':'passed'})
presentation=json.loads((O/'presentation/presentation-results.json').read_text())
assert not presentation['errors'] and len(presentation['results'])==7
checks.append({'name':'Portfolio entry, bilingual navigation, focus return and responsive case presentation','status':'passed'})
final_review=json.loads((O/'final/results.json').read_text())
assert not final_review['errors'] and len(final_review['results'])==4
checks.append({'name':'Final bilingual cases, Cobalt artwork, responsive fit and downloadable 1.5 package','status':'passed'})
controls=json.loads((O/'final/control-results.json').read_text())
assert not controls['errors'] and len(controls['results'])==40
checks.append({'name':'40 form-control checks: both languages, themes and 390/1440px','status':'passed'})
quality={'date':release['date'],'status':'passed','packageVersion':release['version'],'identity':release['identity'],'controlRadius':release['controlRadius'],'routesPerLanguage':verification['routes'],'checks':checks,'inventory':{key:verification[key] for key in ['components','stateSpecimens','patterns','typedTokens','typographyStyles']},'browserReview':['47 routes × Arabic/English × 320/390/768/1440px × light/dark, with native tab, dialog, progress and studio interactions.','Representative Cobalt + Graphite screens visually inspected. Inputs, selects, checkboxes, radios and textareas also passed 40 focused language/theme/viewport checks.'],'limits':['Automated browser checks and representative screenshot review are not a comprehensive human accessibility, screen-reader or language audit.','The Figma companion remains at 1.3. It was inspected, but the Starter-plan MCP call limit prevented identity edits.','Icon Studio uses bundled SVG examples; live model generation remains unconnected.','This local release has not been deployed or published to npm.'],'figmaFile':'https://www.figma.com/design/'+release['figmaFile']}
(D/'downloads/quality-report.json').write_text(json.dumps(quality,ensure_ascii=False,indent=2)+'\n')
(D/'assets/quality-data.js').write_text('window.NASAQ_QUALITY='+json.dumps(quality,ensure_ascii=False)+';\n')
sources=[* (D/'assets').glob('*.css'),* (D/'assets').glob('*.js'),D/'downloads/tokens.json',D/'downloads/nasaq.css']
(O/'release-source-hashes.json').write_text(json.dumps({str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},indent=2)+'\n')
print('Recorded Nasaq '+release['version']+' checks, identity and Figma limitation.')
