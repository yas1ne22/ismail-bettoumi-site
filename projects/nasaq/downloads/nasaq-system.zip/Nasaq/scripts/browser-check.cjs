/* Local visual/interaction regression check. Uses an isolated browser profile. */
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const {chromium} = require(process.env.NASAQ_PLAYWRIGHT || 'playwright');
const base = process.env.NASAQ_URL || 'http://127.0.0.1:4174';
const output = process.env.NASAQ_SCREENSHOTS || path.resolve(__dirname, '../../outputs/nasaq-1.5/browser');
fs.mkdirSync(output, {recursive:true});
const errors = [], checks = [];
async function settled(page) {
  await page.evaluate(async () => {
    await document.fonts.ready;
    window.scrollTo({top:0, behavior:'instant'});
    await new Promise(requestAnimationFrame);
  });
}
async function capture(page, name) {
  await page.locator('.toast.show').waitFor({state:'hidden'});
  await page.evaluate(async () => {
    await Promise.all([...document.images].filter(i => i.getBoundingClientRect().top < innerHeight).map(i => {
      i.loading = 'eager'; return i.decode().catch(() => {});
    }));
  });
  await page.screenshot({path:path.join(output,name+'.png')});
}
async function route(page,id) {
  await page.evaluate(id => {location.hash=id}, id);
  await page.waitForFunction(id => document.querySelector('[data-page="'+id+'"].active'),id);
  await settled(page);
}
async function audit(browser,{lang,width,dark}) {
  const context = await browser.newContext({viewport:{width,height:width<800?844:1000},reducedMotion:'reduce'});
  const page = await context.newPage();
  page.on('pageerror',error=>errors.push({lang,width,dark,error:error.message}));
  await page.goto(base+'/'+(lang==='ar'?'index':'en')+'.html#overview');
  await page.waitForSelector('.system-hero h1');
  if(dark) await page.locator('#theme').click();
  const routes = await page.locator('#side-nav [data-page]').evaluateAll(nodes=>nodes.map(n=>n.dataset.page));
  assert.equal(routes.length,47);
  for(const id of routes) {
    await route(page,id);
    const state = await page.evaluate(() => ({
      scroll:document.documentElement.scrollWidth,viewport:innerWidth,
      headings:document.querySelectorAll('#main h1').length,
      ids:[...document.querySelectorAll('[id]')].map(n=>n.id),
      undefined:document.querySelector('#main').textContent.includes('undefined'),
    }));
    if(state.scroll>state.viewport+1) errors.push({lang,width,dark,route:id,overflow:state.scroll-state.viewport});
    if(state.headings!==1||state.undefined||new Set(state.ids).size!==state.ids.length) errors.push({lang,width,dark,route:id,invalidDOM:state});
    if(['overview','tabs','progress','icon-studio'].includes(id)||width===1440&&!dark&&lang==='en'&&['buttons','colors','components','workflow'].includes(id)) {
      await capture(page,`${lang}-${width}-${dark?'dark':'light'}-${id}`);
    }
  }
  // Independent native instances on the multi-variant canvas, in either direction.
  await route(page,'tabs');
  const frame=page.locator('[data-frame=first]');
  const first=frame.locator('[role=tab]').first(), second=frame.locator('[role=tab]').nth(1);
  await first.focus();await first.press(lang==='ar'?'ArrowLeft':'ArrowRight');
  assert.equal(await second.getAttribute('aria-selected'),'true');
  assert.equal(await frame.locator('[role=tabpanel]').nth(1).isVisible(),true);
  assert.equal(await frame.locator('[role=tabpanel]').first().isVisible(),false);
  assert.equal(await page.locator('[data-frame=second] [role=tab]').nth(1).getAttribute('aria-selected'),'true');
  await second.press('Home');assert.equal(await first.getAttribute('aria-selected'),'true');
  const disabledFrame=page.locator('[data-frame=disabled]');
  assert.equal(await disabledFrame.locator('[role=tab]').nth(1).isDisabled(),true);
  const enabled=disabledFrame.locator('[role=tab]').first();await enabled.focus();await enabled.press('End');
  assert.equal(await enabled.getAttribute('aria-selected'),'true');
  const expand=page.locator('[data-expand]');await expand.click();
  assert.equal(await page.locator('.component-studio').evaluate(n=>n.classList.contains('is-expanded')),true);
  assert.equal(await page.locator('[data-zoom],[data-zoom-value]').count(),0);
  await page.locator('[data-showcase-view=code]').click();assert.equal(await page.locator('[data-showcase-panel=code]').isVisible(),true);
  assert.equal(await page.locator('.nq-code-editor').count(),1);assert((await page.locator('.nq-code-editor .code-tag').count())>0);
  await page.locator('[data-showcase-view=preview]').click();assert.equal(await page.locator('[data-showcase-panel=preview]').isVisible(),true);
  await page.keyboard.press('Escape');assert.equal(await expand.getAttribute('aria-expanded'),'false');
  assert.equal(await expand.evaluate(n=>n===document.activeElement),true);
  // Real native progress states are visible side by side, without fabricated values.
  await route(page,'progress');
  for(const [mode,value] of [['empty','0'],['complete','100'],['indeterminate',null]]) {
    assert.equal(await page.locator('[data-frame='+mode+'] progress').getAttribute('value'),value);
  }
  assert.equal(await page.locator('[data-frame=indeterminate] progress').evaluate(n=>getComputedStyle(n).animationName),'none');
  // Each interactive state changes a surface while preserving foreground opacity.
  await route(page,'buttons');
  const button=page.locator('[data-frame=default] .nq-button');
  for(const variant of ['primary','secondary']) {
    await page.locator('[data-control=variant]').selectOption(variant);
    await page.mouse.move(0,0);
    const before=await button.evaluate(n=>getComputedStyle(n).backgroundColor);
    await button.hover();
    const after=await button.evaluate(n=>({background:getComputedStyle(n).backgroundColor,opacity:getComputedStyle(n).opacity}));
    assert.notEqual(after.background,before);assert.equal(after.opacity,'1');
  }
  // Real studio flow: one description, one style choice, refinement, export readiness.
  await route(page,'icon-studio');
  await page.locator('[data-studio-example=travel]').click();
  await page.locator('[data-studio-choice="style:outline"]').click();
  await page.locator('#studio-prompt').fill(lang==='ar'?'اجعل الخطوط أخف':'Make the lines lighter');
  await page.locator('#studio-prompt').press('Enter');
  assert.equal(await page.locator('.studio-icon-tile').count(),6);
  assert.equal(await page.locator('.icon-studio progress').count(),0);
  await capture(page,`${lang}-${width}-${dark?'dark':'light'}-studio-refinement`);
  await page.locator('[data-studio-choice=approve]').click();
  assert.equal(await page.locator('[data-studio-download]').isVisible(),true);
  const access=page.locator('[data-studio-access]');await access.click();
  assert.equal(await page.locator('.studio-access-dialog').evaluate(n=>n.open),true);
  await page.keyboard.press('Escape');assert.equal(await access.evaluate(n=>n===document.activeElement),true);
  if(width<800) {
    await page.locator('#nav-toggle').click();assert.equal(await page.locator('.sidebar').isVisible(),true);
    await page.keyboard.press('Escape');assert.equal(await page.locator('.sidebar').isVisible(),false);
  }
  checks.push({lang,width,theme:dark?'dark':'light',routes:routes.length,tests:['overflow','unique IDs','headings','tab keyboard and panels','disabled tabs','canvas expansion and HTML view','progress states','reduced motion','button hover','studio refinement and export','dialog focus','mobile menu']});
  console.log(`Checked ${lang} ${width}px ${dark?'dark':'light'}: ${routes.length} routes and interactions`);
  await context.close();
}
(async()=>{
  const browser=await chromium.launch({headless:true,channel:'chrome'});
  try {
    const configs=[];
    for(const lang of ['en','ar'])for(const width of [1440,768,390,320])for(const dark of [false,true])configs.push({lang,width,dark});
    // Two isolated pages at a time keeps the check usable on a local workstation.
    for(let i=0;i<configs.length;i+=2)await Promise.all(configs.slice(i,i+2).map(config=>audit(browser,config)));
    fs.writeFileSync(path.join(output,'browser-results.json'),JSON.stringify({checks,errors},null,2)+'\n');
    assert.deepEqual(errors,[]);
    console.log(`Passed ${checks.length*47} route/viewport/theme combinations.`);
  } finally {await browser.close()}
})().catch(error=>{console.error(error);process.exitCode=1});
