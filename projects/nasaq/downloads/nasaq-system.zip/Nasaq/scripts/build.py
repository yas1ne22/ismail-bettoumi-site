#!/usr/bin/env python3
"""Validate tokens, generate CSS, sync portable assets, build catalogs and ZIPs."""
import json,re,shutil,subprocess,zipfile,tempfile,os
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; DIST=ROOT/'dist'; DL=DIST/'downloads'; AS=DIST/'assets'; SK=DL/'nasaq-ui'
tokens=json.loads((DL/'tokens.json').read_text()); flat={}
def flatten(node,prefix=''):
 for key,value in node.items():
  if key.startswith('$'):continue
  name=prefix+'.'+key if prefix else key
  if isinstance(value,dict) and '$value' in value:flat[name]=value
  elif isinstance(value,dict):flatten(value,name)
flatten(tokens)
valid={'color','dimension','fontFamily','fontWeight','number','duration','shadow','cubicBezier','typography'}
def resolved(v,trail=()):
 if isinstance(v,str) and re.fullmatch(r'\{[^{}]+\}',v):
  name=v[1:-1]
  if name not in flat:raise ValueError('Missing reference '+name)
  if name in trail:raise ValueError('Cyclic reference '+name)
  return resolved(flat[name]['$value'],trail+(name,))
 if isinstance(v,dict):return {k:resolved(x,trail) for k,x in v.items()}
 if isinstance(v,list):return [resolved(x,trail) for x in v]
 return v
def cssvalue(v,kind):
 if kind=='color':
  assert v['colorSpace']=='srgb' and len(v['components'])==3 and all(0<=n<=1 for n in v['components']) and 0<=v.get('alpha',1)<=1
  rgb=[round(n*255) for n in v['components']]
  return 'rgb('+','.join(map(str,rgb))+')' if v.get('alpha',1)==1 else 'rgba('+','.join(map(str,rgb))+','+str(v['alpha'])+')'
 if kind in ('dimension','duration'):
  assert v['unit'] in (('px','rem') if kind=='dimension' else ('ms','s')) and isinstance(v['value'],(float,int))
  return str(v['value'])+v['unit']
 if kind=='fontFamily':return ','.join('"'+s+'"' if ' ' in s else s for s in (v if isinstance(v,list) else [v]))
 if kind=='cubicBezier':
  assert isinstance(v,list) and len(v)==4 and all(isinstance(n,(int,float)) for n in v) and 0<=v[0]<=1 and 0<=v[2]<=1
  return 'cubic-bezier('+','.join(map(str,v))+')'
 if kind=='typography':
  assert set(v)=={'fontFamily','fontSize','fontWeight','letterSpacing','lineHeight'} and v['fontWeight'] in (300,400,700,800) and v['letterSpacing']=={'value':0,'unit':'px'}
  return str(v['fontWeight'])+' '+cssvalue(v['fontSize'],'dimension')+'/'+str(v['lineHeight'])+' '+cssvalue(v['fontFamily'],'fontFamily')
 if kind=='shadow':return ' '.join([cssvalue(v[k],'dimension') for k in ('offsetX','offsetY','blur','spread')]+[cssvalue(v['color'],'color')])
 assert isinstance(v,(int,float))
 return str(v)
def varname(name):
 parts=name.split('.')
 if parts[0]=='color':parts=parts[1:] if parts[1]!='muted' else parts
 elif parts[0]=='semantic':parts=['bg' if parts[2]=='background' else parts[2]]
 elif parts[0]=='component' and len(parts)>3 and parts[2] in ('light','dark'):parts.pop(2)
 return '--nq-'+'-'.join(parts)
base=[];light=[];dark=[]
for name,t in flat.items():
 assert t['$type'] in valid,(name,t['$type'])
 v=t['$value'];value=resolved(v,(name,));cssvalue(value,t['$type'])
 if isinstance(v,str) and v.startswith('{'):
  ref=flat[v[1:-1]];assert ref['$type']==t['$type'],name
  val='var('+varname(v[1:-1])+')'
 else:val=cssvalue(value,t['$type'])
 line=f' {varname(name)}:{val};'
 (dark if name.startswith('semantic.dark.') or '.dark.' in name else light if name.startswith('semantic.light.') or '.light.' in name else base).append(line)
for name,t in flat.items():
 if name.startswith('type.'):
  base.append(' --nq-type-ar-'+name[5:]+':'+cssvalue(resolved(t['$value'],(name,)),'typography')+';')
block='\n/* GENERATED TOKENS START — edit tokens.json, run scripts/build.py */\n:root, [data-theme="light"] {\n'+'\n'.join(base+light)+'\n}\n[data-theme="dark"] {\n'+'\n'.join(dark)+'\n}\n/* GENERATED TOKENS END */\n'
css=(DL/'nasaq.css').read_text();css=re.sub(r'\n/\* GENERATED TOKENS START[\s\S]*?/\* GENERATED TOKENS END \*/\n','\n',css).rstrip();css+=block
(DL/'nasaq.css').write_text(css);(AS/'nasaq.css').write_text(css.replace('assets/fonts.css','fonts.css'))
for folder in (DL/'assets',SK/'assets',DL/'mcp/assets'):
 folder.mkdir(parents=True,exist_ok=True)
 shutil.copytree(AS/'lucide',folder/'lucide',dirs_exist_ok=True)
 for p in AS.iterdir():
  if p.suffix in ('.svg','.ttf') or p.name in ('fonts.css','almarai-OFL.txt','inter-OFL.txt'):shutil.copy2(p,folder/p.name)
shutil.copy2(AS/'nasaq.css',SK/'assets/nasaq.css');shutil.copy2(AS/'nasaq.css',DL/'mcp/assets/nasaq.css')
for target in (AS/'nasaq.js',SK/'assets/nasaq.js'):shutil.copy2(DL/'nasaq.js',target)
for target in (SK/'assets/tokens.json',DL/'mcp/tokens.json'):shutil.copy2(DL/'tokens.json',target)
# The portfolio popup consumes the same semantic colors without importing site-wide styles.
popup=[]
for mode,selectors in [('light','.nasaq-language-dialog,.nasaq-entry-page'),('dark','[data-theme="dark"] .nasaq-language-dialog,[data-theme="dark"] .nasaq-entry-page,.nasaq-language-dialog[data-theme="dark"]')]:
 rules=[f' {varname(name)}:{cssvalue(resolved(token["$value"],(name,)),token["$type"])};' for name,token in flat.items() if name.startswith('semantic.'+mode+'.')]
 popup.append(selectors+'{\n'+'\n'.join(rules)+'\n}')
(AS/'onboarding-theme.css').write_text('/* Generated from tokens.json by scripts/build.py. */\n'+'\n'.join(popup)+'\n')
(AS/'tokens-data.js').write_text('window.NASAQ_TOKENS='+json.dumps(tokens,ensure_ascii=False)+';\n')
shutil.copy2(SK/'SKILL.md',DL/'mcp/SKILL.md')
shutil.copytree(SK/'references',DL/'mcp/references',dirs_exist_ok=True)
subprocess.run(['node',str(ROOT/'scripts/catalog.cjs')],check=True)
subprocess.run(['node',str(ROOT/'scripts/build_english.cjs')],check=True)
(DL/'mcp/assets/brand').mkdir(exist_ok=True)
for p in (DL/'brand-kit').iterdir():
 if p.suffix in ('.svg','.json'):shutil.copy2(p,DL/'mcp/assets/brand'/p.name)
# Brand kit is self-contained with the guide under brand-kit/ and shared assets beside it.
for p in AS.iterdir():
 if p.name.startswith('misc-') or p.name.endswith('.ttf') or p.name in ('almarai-OFL.txt','inter-OFL.txt','fonts.css'):shutil.copy2(p,DL/'brand-kit'/p.name)
subprocess.run(['python3',str(ROOT/'scripts/build_npm.py')],check=True)
def archive(name,items):
 fd,temporary=tempfile.mkstemp(prefix='.nasaq-archive-',suffix='.tmp',dir=DL)
 os.close(fd)
 try:
  with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED) as z:
   for file,rel in items:
    if not file.name.startswith('.nasaq-archive-'):z.write(file,rel)
  os.chmod(temporary,0o644)
  Path(temporary).replace(DL/name)
 finally:
  Path(temporary).unlink(missing_ok=True)
archive('nasaq-lucide-icons.zip',[(p,'lucide/'+p.name) for p in (AS/'lucide').iterdir() if p.is_file()])
archive('nasaq-mcp.zip',[(p,'nasaq-mcp/'+str(p.relative_to(DL/'mcp'))) for p in (DL/'mcp').rglob('*') if p.is_file() and '__pycache__' not in str(p)])
archive('nasaq-brand-kit.zip',[(p,'nasaq-brand-kit/brand-kit/'+str(p.relative_to(DL/'brand-kit'))) for p in (DL/'brand-kit').rglob('*') if p.is_file()]+[(DL/'nasaq.css','nasaq-brand-kit/nasaq.css')]+[(p,'nasaq-brand-kit/assets/'+p.name) for p in (DL/'assets').iterdir() if p.is_file()])
archive('nasaq-ui-skill.zip',[(p,str(p.relative_to(DL))) for p in SK.rglob('*') if p.is_file()])
archive('nasaq-case-study.zip',[(p,str(p.relative_to(DIST))) for p in DIST.rglob('*') if p.is_file() and p.suffix!='.zip' and '__pycache__' not in str(p)])
archive('nasaq-system.zip',[(p,'Nasaq/'+str(p.relative_to(ROOT))) for p in ROOT.rglob('*') if p.is_file() and p.name!='nasaq-system.zip' and '__pycache__' not in str(p) and '/.git/' not in str(p)])
print(f'Built {len(flat)} typed tokens, catalogs, portable examples and six ZIP packages.')
