// Presentation contracts for the portfolio entry, case study and Nasaq cleanup.
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict');
const {chromium}=require(process.env.NASAQ_PLAYWRIGHT||'playwright');
const base=process.env.NASAQ_PORTFOLIO||'http://localhost:3000';
const output=process.env.NASAQ_REVIEW||path.resolve(__dirname,'../../outputs/nasaq-1.5/presentation');
fs.mkdirSync(output,{recursive:true});
const results=[],errors=[];
async function screenshot(page,name){
 await page.mouse.move(0,0);
 await page.evaluate(async()=>{await document.fonts.ready;await Promise.all([...document.images].filter(n=>n.getBoundingClientRect().top<innerHeight).map(n=>{n.loading='eager';return n.decode().catch(()=>{})}))});
 await page.screenshot({path:path.join(output,name+'.png')});
}
async function noOverflow(page){assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),true,page.url())}
async function monoHeadings(page){
 const bad=await page.evaluate(()=>[...document.querySelectorAll('h1,h2,h3,h4')].filter(h=>h.getClientRects().length).flatMap(h=>{
  const base=getComputedStyle(h).color;
  return [...h.querySelectorAll('span,em,strong')].filter(n=>n.textContent.trim()&&getComputedStyle(n).color!==base).map(n=>n.textContent);
 }));
 assert.deepEqual(bad,[],page.url());
}
async function artwork(page){
 const images=await page.locator('.nasaq-artwork img').evaluateAll(nodes=>nodes.filter(n=>n.getClientRects().length).map(n=>({fit:getComputedStyle(n).objectFit,ratio:n.getBoundingClientRect().width/n.getBoundingClientRect().height,visualCase:!!document.body.dataset.visualCase})));
 for(const image of images){assert.equal(image.fit,'contain');if(!image.visualCase)assert(Math.abs(image.ratio-1.5)<.025)}
}
(async()=>{
 const browser=await chromium.launch({headless:true,channel:'chrome'});
 try{
  for(const width of [1440,390,320]){
   const context=await browser.newContext({viewport:{width,height:width<800?844:1000},reducedMotion:'reduce'}),page=await context.newPage();
   page.on('pageerror',e=>errors.push(e.message));
   await page.goto(base+'/');
   if(await page.locator('#skip-intro').isVisible())await page.locator('#skip-intro').click();
   if(await page.locator('#gate').count())await page.locator('#gate').waitFor({state:'hidden'});
   await page.waitForSelector('a.case[href*="/projects/nasaq/"]');
   await noOverflow(page);await screenshot(page,'portfolio-'+width);
   if(await page.locator('#work-nasaq a.case').count()){
    const opener=page.locator('#work-nasaq a.case');await opener.click();
    const dialog=page.locator('dialog.nasaq-language-dialog');await dialog.waitFor({state:'visible'});
    const box=await dialog.boundingBox();assert(Math.abs(box.x+box.width/2-width/2)<2);assert(Math.abs(box.y+box.height/2-(width<800?844:1000)/2)<2);
    await screenshot(page,'popup-'+width+'-language');
    await page.locator('[data-language=ar]').click();assert.equal(await dialog.getAttribute('dir'),'rtl');
    await screenshot(page,'popup-'+width+'-experience');
    assert.equal(await page.locator('.nasaq-onboarding-count').textContent(),'2 / 2');
    assert.equal(await page.locator('[data-final]').count(),2);
    assert((await page.locator('[data-format=case]').getAttribute('href')).endsWith('case-study.html#brief'));
    await page.locator('[data-onboarding-back]').click();await page.keyboard.press('Escape');
    assert.equal(await opener.evaluate(n=>n===document.activeElement),true);
   }else{
    // The restored original homepage opens the case in its native showcase dialog.
    const opener=page.locator('a.case[href*="/projects/nasaq/"]').first();await opener.click();
    const dialog=page.locator('#plugin-showcase-dialog');await dialog.waitFor({state:'visible'});
    assert((await page.locator('#plugin-showcase-frame').getAttribute('src')).includes('/projects/nasaq/'));
    await page.frameLocator('#plugin-showcase-frame').locator('.case-opening h1').waitFor();
    await screenshot(page,'popup-'+width+'-case');
    await page.locator('#plugin-showcase-close').click();assert.equal(await dialog.isVisible(),false);
    assert.equal(await opener.evaluate(n=>n===document.activeElement),true);
   }
   for(const lang of ['en','ar'])for(const dark of [false,true]){
    const file=lang==='ar'?'index':'en';
    for(const route of ['overview','foundations','components','start']){
     await page.goto(`${base}/projects/nasaq/${file}.html#${route}`);await page.waitForSelector('main h1');
     await page.evaluate(dark=>document.documentElement.dataset.theme=dark?'dark':'light',dark);
     await noOverflow(page);await monoHeadings(page);await artwork(page);
     const identity=await page.evaluate(()=>{const s=getComputedStyle(document.documentElement);return {action:s.getPropertyValue('--nq-action').replace(/\s/g,''),radius:s.getPropertyValue('--nq-component-button-radius').trim(),brand:getComputedStyle(document.querySelector('.brand>img')).filter}});
     assert.equal(identity.action,dark?'rgb(142,178,255)':'rgb(29,78,216)');
     assert.equal(await page.locator('.nq-button').first().evaluate(n=>getComputedStyle(n).borderRadius),'12px');
     if(dark)assert(identity.brand.includes('invert(1)'));
     if(route==='overview'){
      assert.equal(await page.locator('.system-facts,.nasaq-area-card[data-area=overview],.nasaq-art-label,.nasaq-area-card-title>span').count(),0);
      assert.equal(await page.locator('.nasaq-area-card').count(),5);
     }
     if(route==='foundations')assert.equal(await page.locator('#main h1').textContent(),lang==='ar'?'الأسس':'Foundations');
     if(route==='start'){
      await page.locator('#setup-files-tab').click();assert.equal(await page.locator('#setup-files-panel').isVisible(),true);assert.equal(await page.locator('#setup-npm-panel').isVisible(),false);
      await page.locator('#setup-files-tab').press(lang==='ar'?'ArrowLeft':'ArrowRight');assert.equal(await page.locator('#setup-skill-tab').getAttribute('aria-selected'),'true');
      await page.locator('#setup-npm-tab').click();
      await page.locator('.start-language-example>summary').click();await page.locator('[data-control=name]').fill('A retained draft العربية');
      await page.locator('[data-control=lang]').selectOption(lang==='ar'?'en':'ar');assert.equal(await page.locator('[data-control=name]').inputValue(),'A retained draft العربية');
      await page.locator('.start-language-example>summary').click();
     }
     await page.evaluate(()=>scrollTo({top:0,behavior:'instant'}));
     if(width!==320)await screenshot(page,`${lang}-${width}-${dark?'dark':'light'}-${route}`);
    }
    const casefile=lang==='ar'?'case-study.html':'case-study-en.html';
    await page.goto(`${base}/projects/nasaq/${casefile}`);await page.waitForSelector('.case-opening h1');
    if((await page.locator('#case-theme').getAttribute('aria-pressed'))!==String(dark))await page.locator('#case-theme').click();
    await noOverflow(page);await monoHeadings(page);await artwork(page);
    assert.equal(await page.locator('.case-facts').isVisible(),true);
    await page.evaluate(()=>location.hash='trace');
    assert((await page.locator('.case-locale').getAttribute('href')).endsWith('#trace'));
    await page.evaluate(()=>{history.replaceState(null,'',location.pathname);scrollTo({top:0,behavior:'instant'})});
    if(width!==320)await screenshot(page,`${lang}-${width}-${dark?'dark':'light'}-case`);
   }
   results.push({viewport:width,caseAndLearning:'passed',popupCenteringAndFocus:'passed',headingColorAndImageFit:'passed'});await context.close();
  }
  // The second question navigates directly in either language.
  const context=await browser.newContext({viewport:{width:1440,height:1000},reducedMotion:'reduce'}),page=await context.newPage();
  for(const lang of ['en','ar'])for(const format of ['case','system']){
   await page.goto(base+'/projects/nasaq/explore.html');await page.locator('[data-language='+lang+']').click();
   assert.equal(await page.locator('.nasaq-onboarding-count').textContent(),'2 / 2');
   await page.locator('[data-format='+format+']').click();
   await page.waitForURL(url=>url.hash===(format==='case'?'#brief':'#overview'));assert.equal(page.frames().length,1);
   const expected=format==='case'?(lang==='ar'?'case-study.html':'case-study-en.html'):(lang==='ar'?'index.html':'en.html');assert.equal(new URL(page.url()).pathname,'/projects/nasaq/'+expected);
   results.push({language:lang,format,fullPageNavigation:'passed'});
  }
  await context.close();assert.deepEqual(errors,[]);
  fs.writeFileSync(path.join(output,'presentation-results.json'),JSON.stringify({results,errors},null,2)+'\n');
  console.log('Passed: portfolio case entry, two-question language flow, 4 destinations, Cobalt/Graphite roles, 12px controls, dark mark, image fit, case themes and quickstart drafts.');
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
