// Check navigation contracts and recovery behavior without a browser mock.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const dist = path.resolve(__dirname, '../dist');
const context = vm.createContext({ URL });
for (const file of ['onboarding.js', 'workflow.js']) {
  vm.runInContext(fs.readFileSync(path.join(dist, 'assets', file), 'utf8'), context);
}
const { destination } = context.NasaqOnboarding;
const targets = {
  case: { icons: 'icon-studio', decisions: 'decisions', components: 'trace', language: 'language', beginning: 'brief' },
  system: { icons: 'icon-studio', decisions: 'project', components: 'buttons', language: 'quality', beginning: 'overview' },
};
let journeys = 0;
for (const language of ['ar', 'en']) for (const format of ['case', 'system']) {
  for (const [focus, hash] of Object.entries(targets[format])) {
    const url = new URL(destination(language, format, focus, 'https://example.test/projects/nasaq/'));
    const expected = format === 'case' ? (language === 'en' ? 'case-study-en.html' : 'case-study.html') : (language === 'en' ? 'en.html' : 'index.html');
    assert.equal(url.pathname, '/projects/nasaq/' + expected);
    assert.equal(url.hash, '#' + hash);
    const html = fs.readFileSync(path.join(dist, expected), 'utf8');
    if (format === 'case') assert.ok(html.includes('id="' + hash + '"'), `${language}/${format}/${focus}: missing section`);
    journeys++;
  }
}
const { initial, reduce } = context.NASAQ_WORKFLOW;
const sample = { name: 'موجز.txt', size: 718, sample: true };
let state = initial();
assert.strictEqual(reduce(state, { type: 'submit', prompt: 'Read this' }), state, 'Cannot submit without a source');
state = reduce(state, { type: 'attach', attachment: sample });
assert.strictEqual(reduce(state, { type: 'submit', prompt: '  ' }), state, 'Cannot submit an empty prompt');
const question = 'What happens to user input after a failed request?';
state = reduce(state, { type: 'submit', prompt: question });
assert.equal(state.phase, 'generating');
assert.strictEqual(reduce(state, { type: 'submit', prompt: 'Duplicate request' }), state, 'No duplicate submission');
state = reduce(state, { type: 'cancel' });
assert.equal(state.phase, 'cancelled');
assert.equal(state.prompt, question);
assert.strictEqual(state.attachment, sample);
assert.strictEqual(reduce(state, { type: 'complete' }), state, 'Late completion cannot revive a cancelled result');
state = reduce(state, { type: 'submit', prompt: state.prompt });
state = reduce(state, { type: 'fail' });
assert.equal(state.phase, 'error');
assert.equal(state.prompt, question);
assert.strictEqual(state.attachment, sample);
state = reduce(state, { type: 'submit', prompt: state.prompt });
state = reduce(state, { type: 'complete' });
assert.equal(state.phase, 'complete');
assert.equal(state.attempts, 3);
assert.equal(state.prompt, question);
assert.strictEqual(state.attachment, sample);
state = reduce(state, { type: 'reset' });
assert.equal(state.phase, 'idle');
assert.equal(state.attachment, null);
assert.equal(state.prompt, '');
assert.strictEqual(reduce(state, { type: 'fail' }), state, 'Late failure cannot change a reset example');
console.log(`Passed: ${journeys} bilingual onboarding destinations; validation, duplicate prevention, cancellation, late results, failure, retry and reset.`);
