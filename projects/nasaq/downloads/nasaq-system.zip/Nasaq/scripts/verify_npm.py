#!/usr/bin/env python3
"""Install the actual tarball in an isolated consumer and verify package entry points/assets."""
from pathlib import Path
import json,os,subprocess,tempfile,tarfile,re,shutil
R=Path(__file__).resolve().parents[1];DL=R/'dist/downloads';meta=json.loads((DL/'npm-package.json').read_text());archive=DL/meta['filename']
env=dict(os.environ,NPM_CONFIG_CACHE='/private/tmp/nasaq-npm-cache',NPM_CONFIG_UPDATE_NOTIFIER='false')
with tarfile.open(archive) as tar:
 names=tar.getnames()
 assert len([n for n in names if '/assets/lucide/' in n and n.endswith('.svg')])==2130
 for name in ('LICENSE','THIRD_PARTY_NOTICES.md','assets/inter-OFL.txt','assets/almarai-OFL.txt','assets/lucide/LICENSE','lib/index.d.ts','lib/index.d.cts'):assert 'package/'+name in names,name
 assert not any('/src/' in n or '/test/' in n or '/node_modules/' in n for n in names)
with tempfile.TemporaryDirectory(prefix='nasaq-npm-',dir='/private/tmp') as temporary:
 p=Path(temporary);(p/'package.json').write_text('{"private":true,"type":"module"}')
 result=subprocess.run(['npm','install','--offline','--ignore-scripts','--no-audit','--no-fund',str(archive)],cwd=p,env=env,check=True,capture_output=True,text=True)
 check='''import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {initNasaq,getToken,tokenNames,version} from '@nasaq/ui';
const require=createRequire(import.meta.url),cjs=require('@nasaq/ui');
assert.equal(version,'1.5.0');assert.equal(tokenNames.length,340);
assert.equal(getToken('type-en.body-md').fontFamily[0],'Inter');
assert.equal(getToken('type.body-md').fontFamily[0],'Almarai');
assert.equal(typeof initNasaq(),'function');
assert.deepEqual(cjs.getToken('motion.easing.enter'),getToken('motion.easing.enter'));
assert.equal(Object.keys(require('@nasaq/ui/components.en.json')).length,18);
assert.equal(Object.keys(require('@nasaq/ui/patterns.en.json')).length,12);
assert(require.resolve('@nasaq/ui/icons/search.svg').endsWith('search.svg'));
console.log('Installed package: ESM, CommonJS, SSR, tokens, JSON and SVG exports passed.');'''
 (p/'check.mjs').write_text(check)
 subprocess.run(['node','check.mjs'],cwd=p,check=True)
 installed=p/'node_modules/@nasaq/ui'
 css=(installed/'styles/nasaq.css').read_text()
 assert (installed/'tokens.json').read_bytes()==(DL/'tokens.json').read_bytes()
 assert css==(DL/'nasaq.css').read_text().replace('assets/fonts.css','../assets/fonts.css'), 'Installed CSS differs from packed source' 
 for file in (installed/'styles/nasaq.css',installed/'assets/fonts.css'):
  for url in re.findall(r'url\([\'"]?([^\)\'\"]+)',file.read_text()):assert (file.parent/url).exists(),url
 # Reuse the workspace's installed Vite for a real production consumer build.
 vite=R.parent/'ISMUX/node_modules/vite/bin/vite.js'
 if vite.exists():
  for name in ('index.html','main.js','example.css'):shutil.copy2(R/'examples/vite'/name,p/name)
  result=subprocess.run(['node',str(vite),'build','--base','./'],cwd=p,check=True,capture_output=True,text=True)
  output=p/'dist';assert (output/'index.html').exists()
  built='\n'.join(f.read_text() for f in (output/'assets').glob('*.css'))
  assert 'Inter' in built and 'Almarai' in built and '[lang=en][dir]' in built
  assert len(list((output/'assets').glob('*.ttf')))==5
  print('Vite production consumer: styles, five local fonts, SVG imports and both language scopes passed.')
 else:print('Vite consumer build unavailable; package entry-point and asset checks passed.')
