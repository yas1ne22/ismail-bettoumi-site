# Nasaq / نسق — 1.5

Arabic-first AI design system with Almarai for Arabic and Inter for English. Open `dist/explore.html` to choose a language and enter the case study or live documentation. Direct documentation links remain `dist/index.html` (Arabic) and `dist/en.html` (English); case studies are `dist/case-study.html` and `dist/case-study-en.html`. No install or web server is required to view the pages.

The portfolio opens all three questions in one project popup. Each language keeps the case study and documentation connected; the documentation language switch preserves the current route. `assets/journey.js` remembers the last language without skipping the choice, synchronizes the popup’s full-page link, and returns embedded visitors to the portfolio with focus restored. Standalone pages use a normal portfolio link.

47 documentation routes in each language: eight foundation groups; 18 components with visible state galleries; six marketing compositions; 12 AI/product patterns; brand kit, typed tokens, AI project guide, skill and MCP setup.

## Download packages

- `dist/downloads/nasaq-system.zip`: complete workspace source including dist, build/verification scripts and the other download packages. Rebuild to regenerate this full-system archive after extracting.
- `nasaq-lucide-icons.zip`: 2,130 local SVG icons, searchable metadata and Lucide/Feather license notices.
- `nasaq-ui-skill.zip`: skill, references, CSS, interaction script, tokens, fonts, icons and misc symbols.
- `nasaq-brand-kit.zip`: symbols, editable live-text SVG lockups, social template, avatar, palette and self-contained brand guide.
- `nasaq-mcp.zip`: local read-only stdio MCP server and its data/assets, setup instructions and protocol tests. Python 3.10+, no extra dependencies.
- `nasaq-case-study.zip`: visual case study, documentation and assets. ZIP download links in this extracted package require copying the download ZIPs from the full system or rebuilding them.

## Maintain the system

Source values: `dist/downloads/tokens.json` (DTCG Format 2025.10). Primitive → semantic light/dark → component aliases. Source styles: `dist/downloads/nasaq.css`; generated variables are marked. Source interactions: `dist/downloads/nasaq.js`. Documentation/components/state examples: `dist/assets/docs.js`. Catalog is generated from those definitions, not manually maintained.

From this directory:

```sh
python3 scripts/build.py
python3 scripts/verify.py
```

Build requires Python 3.10+ and Node 18+. It validates token references/types/cycles, generates mode-aware CSS, syncs the skill/assets, builds portable examples and MCP catalog, and refreshes six archives. No package installation required. Edit source files, not synchronized copies or generated catalog.

## AI and MCP

Open docs → “AI في مشروعك” for the workflow and reusable prompt. Skill users should attach/read `dist/downloads/nasaq-ui/SKILL.md` with its references and assets. The skill guides implementation; it does not run a model.

Open docs → “واجهة MCP” or read `dist/downloads/mcp/README.md` to connect an MCP client. Set a local stdio command `python3` and absolute path to the bundled `server.py`. Nothing is registered automatically. The server is read-only and has no hosted endpoint. It exposes six tools, five resources and one implementation prompt. To test it independently:

```sh
python3 dist/downloads/mcp/test_server.py
```

## Visual and interaction rules

A cool neutral canvas, white cards, cobalt actions and graphite navigation; explicit hover, pressed, selected and disabled roles in both modes. Brand compositions use semantic blue and neutral surfaces with explicit foregrounds. Red remains a feedback color. Native controls and RTL logical properties. Switch geometry is 48×28px with 20px thumb and 44px label target. State specimens pin focus/hover/pressed for comparison; main previews use actual native interaction. Chat, billing, uploads, analytics and AI responses are illustrative local demonstrations, not connected services.

SVG lockups/templates use editable text with embedded Almarai; install the fonts when editing in software that discards embedded font styles; geometric marks do not require a font. Fonts are bundled with SIL OFL. Original Nasaq mark/icons/components; Thmanyah was a visual inspiration, its proprietary assets are not bundled. The user-supplied FDS skill was a reference for organizing design rules; its presentation-specific instructions are not operative Nasaq rules.

## Expanded foundations

Lucide Static 1.52.0: 2,130 offline SVGs, searchable in the Icons page, with upstream ISC/Feather MIT license and version manifest. Download nasaq-lucide-icons.zip. Existing 26 Nasaq utility icons and 16 original misc symbols remain separate.

Colors: eight shade families × eleven steps (50–950), 88 additional primitives. Typography: 19 named Almarai styles plus 19 Inter styles via DTCG typography composites. Motion: durations, easing curves, distances, scale/opacity and semantic interaction roles; live Motion & Interaction page and portable motion.html. Respect system reduced-motion and native state/keyboard behavior.

The oversized red overview introduction and red case-study cover have been deleted. No large red section remains in docs or case study; coral is documented in the color foundations only.

## npm package

`@nasaq/ui` 1.5.0 is generated under packages/ui. Install the local dist/downloads/nasaq-ui-1.5.0.tgz tarball with npm; it is not published to the registry. See the website npm tab or packages/ui/README.md for Vite, React/Next.js, API, TypeScript and lifecycle usage. Full build generates the tarball offline, without registry uploads.

English docs cover the same 47 routes, 18 components and state galleries, 12 patterns, brand and AI/MCP guidance. type-en tokens and lang=en/dir=ltr use Inter; nested Arabic scopes restore Almarai. Case study: dist/case-study-en.html. MCP component/pattern/search tools accept language=en, with Arabic default.

## Icon Studio

Open `dist/en.html#icon-studio` or `dist/index.html#icon-studio` for the English / Arabic conversational icon workflow. Describe an idea → answer one style question → preview and refine in the same chat → download the six SVG examples together. The first screen has one empty composer and optional starting ideas. Grids, technical settings, inspectors and the workflow stepper are removed. Typed refinements support line weight, line endings and outline / two-tone styling; requests for custom geometry stay in the brief and explain the live-access requirement. The ZIP contains six SVGs matching the preview plus the generation brief. Live generation requires authenticated model access and paid usage, so it is not enabled on the portfolio.

The portfolio adds a direct studio entry and an onboarding starting point. Runtime checks for the experience live in `../ISMUX/tests/icon-studio.test.mjs` and run with the portfolio's `npm test`.

## 1.4 interface release

The documentation shell, overview component showcase, component workbench, tabs, progress and Icon Studio now share the same 326 typed tokens. Hover changes the control background without reducing text opacity. Selected tabs combine a fill and border; keyboard focus remains separate. Native progress uses an 8px track, written values when known, and a reduced-motion-compatible indeterminate state. Studio shows conversation status rather than a percentage.

`dist/assets/interface.css` owns the documentation presentation; `dist/downloads/nasaq.css` owns exported components; `dist/downloads/tokens.json` is their mode-aware color source. The colors route documents the new role contract. Generated CSS now supports explicit nested light scopes in a dark host.

`node scripts/browser-check.cjs` runs the local regression and screenshot sweep against `http://127.0.0.1:4174`. Set `NASAQ_PLAYWRIGHT` to an installed Playwright module and `NASAQ_URL` to another local preview if needed. The test uses an isolated headless Chrome profile. Screenshot evidence and the audit are in `../outputs/nasaq-1.4/`. The Figma companion retains its recorded 1.3 release; the website/package release is 1.4. No Figma synchronization or live deployment is implied.


## 1.4 presentation cleanup

The main and alternate portfolio layouts share `src/nasaqOnboarding.js` in the portfolio source. The modal asks language, experience and starting point before normal full-page navigation; modifier-key links retain the standalone fallback. `onboarding-theme.css` is generated from the same semantic tokens as the system.

The overview omits repeated inventory counts and the redundant Overview card. Section links have one title; generated artwork keeps its complete 3:2 composition. Category navigation links replace repeated headings and index links. Headings use one foreground color. The bilingual case study uses the system's 1.4 surfaces and a shared appearance setting. Get started leads with installation tabs and language setup; its editable direction example remains available in an optional disclosure.

Run `node scripts/presentation-check.cjs` with the same `NASAQ_PLAYWRIGHT` setting as the browser sweep to check popup navigation, centering, focus return, image fit, title colors, quickstart behavior and the case study at desktop and mobile widths. Screenshot evidence is in `../outputs/nasaq-1.4-cleanup/`.


## 1.5 — Cobalt + Graphite

The approved identity uses cobalt #1D4ED8 for light-mode actions, graphite #151A22 for navigation, and a #F4F6F8 canvas. Dark mode uses its corresponding semantic roles. Buttons, fields, tabs and cards use the selected 12px radius. There are now 340 typed tokens, including inverse surface/text/selection roles and two brand primitives.

Documentation, case studies, onboarding, native CSS, portable examples, npm/MCP/skill bundles, brand kit and scalable technical artwork consume the same identity. The existing pastel primitives remain available for compatibility and deliberate secondary uses. See CHANGELOG.md for migration notes. This is a local source/package release; rebuilding does not publish or deploy it.


For 1.5 review evidence, run the browser check with its default output at `../outputs/nasaq-1.5/browser/` and the presentation check at `../outputs/nasaq-1.5/presentation/`. After source/package verification and the full browser sweep pass, `python3 scripts/record_release.py` refreshes the dated quality record. Rebuild the archives after changing that record.
