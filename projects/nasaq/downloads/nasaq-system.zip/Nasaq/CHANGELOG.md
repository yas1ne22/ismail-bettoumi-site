# Nasaq 1.5.0 — 26 October 2026

The approved Cobalt + Graphite identity applies to the documentation, native components, bilingual case study, entry flow, brand assets, implementation skill and local distribution packages.

- Cobalt `#1D4ED8` identifies primary actions in light mode; `#8EB2FF` is the matching dark-mode action. Both have explicit foreground, hover and pressed roles.
- Graphite navigation uses inverse surface, text, muted text, divider, selection and accent roles. Neutral canvases, white surfaces and visible field boundaries replace the violet presentation.
- Buttons, fields, tabs and cards use the selected 12px radius. Native switch, avatar and progress geometry keep their functional shapes.
- Scalable cobalt and graphite illustrations replace the decorative pastel covers in the active documentation and case study.
- Existing public classes, 18 component families, 12 product patterns, typography names and 88 shade primitives remain available. Fourteen tokens were added, bringing the typed catalog to 340.

## Migration from 1.4

Install `nasaq-ui-1.5.0.tgz`, import its stylesheet once, and keep using semantic or component variables. Existing `color.pink`, `color.lavender` and `color.mint` primitives remain available for compatibility and deliberate secondary uses; they no longer define the Nasaq brand surfaces. Replace hardcoded 1.4 colors with semantic roles.

Light is the default appearance. Explicit dark preferences remain supported with the corresponding cobalt and graphite roles. Building this release does not publish to npm or deploy a live website.
