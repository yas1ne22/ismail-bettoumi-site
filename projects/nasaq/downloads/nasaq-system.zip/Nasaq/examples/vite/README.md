# Nasaq bilingual Vite example

From this folder, run `npm install` then `npm run dev`. The local @nasaq/ui tarball is built by the complete workspace's build script. Vite is the only development dependency.

Examples: English/Arabic language scopes, local fonts, SVG imports, light/dark theme, native switches, keyboard tabs and native dialogs. No network AI/data requests. Language switching changes root typography/direction; explicitly scoped Arabic and English panels remain in their own languages.
