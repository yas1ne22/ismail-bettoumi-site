import '@nasaq/ui/styles.css';
import { initNasaq, getToken } from '@nasaq/ui';
import searchUrl from '@nasaq/ui/icons/search.svg?url';
import logoUrl from '@nasaq/ui/assets/nasaq-mark.svg?url';
import './example.css';
const cleanup = initNasaq(document);
document.querySelector('#search-icon').src = searchUrl;
document.querySelector('#logo').src = logoUrl;
document.querySelector('#token-summary').textContent = `Reveal duration: ${getToken('interaction.reveal.duration').value}ms · bundled Inter + Almarai`;
document.querySelector('#language').addEventListener('click', event => {
  const english = document.documentElement.lang !== 'en';
  document.documentElement.lang = english ? 'en' : 'ar';
  document.documentElement.dir = english ? 'ltr' : 'rtl';
  event.currentTarget.textContent = english ? 'العربية' : 'English';
});
document.querySelector('#theme').addEventListener('click', () => {
  document.documentElement.dataset.theme = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark';
});
if (import.meta.hot) import.meta.hot.dispose(cleanup);
