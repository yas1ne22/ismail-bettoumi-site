# @nasaq/ui

Bilingual Nasaq design system: Arabic/RTL with Almarai and English/LTR with Inter. Framework-independent CSS components, 286 typed tokens, 2,130 Lucide SVG icons, local fonts, and native dialog/tab/tooltip helpers. Zero runtime dependencies. No automatic DOM access during import.

## Install now

This package is supplied as a local tarball; it has **not been published to the npm registry**. Download `nasaq-ui-1.3.0.tgz` from the documentation, put it in your project, and run:

```sh
npm install ./nasaq-ui-1.3.0.tgz
```

Once the owner publishes the scoped package, registry installation can use `npm install @nasaq/ui`. The scope's availability and ownership must be checked before publication.

## Vanilla / Vite

```js
import '@nasaq/ui/styles.css';
import { initNasaq, getToken } from '@nasaq/ui';

const cleanup = initNasaq(document);
console.log(getToken('type-en.body-md')); // resolved English typography
// Call cleanup() when the owning surface is unmounted.
```

```html
<html lang="en" dir="ltr">
  <body class="nq">
    <button class="nq-button">Start writing</button>
    <label class="nq-check">
      <input type="checkbox" role="switch" class="nq-switch">
      Save history
    </label>
    <section class="nq" lang="ar" dir="rtl">
      <p class="nq-type-body-md">أفكارك، بصوتك أنت.</p>
    </section>
  </body>
</html>
```

CSS imports the bundled fonts. Keep the CSS and font assets together when copying files manually. Base styles include global focus/reduced-motion rules; load once at the application entry. Importing JS alone does not import CSS. For SSR frameworks, import the stylesheet in the supported global-style entry and run initNasaq only on the client.

## React and Next.js

Use native elements with Nasaq classes; this package does not provide React component wrappers. Import the stylesheet in your app's global entry. A client-side shell can attach the native helpers:

```jsx
'use client';
import { useEffect } from 'react';
import { initNasaq } from '@nasaq/ui';

export function NasaqBehavior() {
  useEffect(() => initNasaq(document), []);
  return null;
}
```

Set the root `<html lang="en" dir="ltr">` or `<html lang="ar" dir="rtl">`, and `className="nq"` on the body. React's effect cleanup removes the listeners. Mount one behavior shell; avoid overlapping roots. Native switches/checkboxes need no extra JS and remain controlled by your application when using controlled inputs.

## Native tabs, dialogs and tooltips

- Tabs: `[data-tabs]` wrapper, `role="tablist"`, button `role="tab"`, `aria-controls` pointing to `role="tabpanel"`, and `aria-selected`. Arrow keys follow computed RTL/LTR direction; Home and End are supported. Use unique panel IDs.
- Dialog: `data-open="dialog-id"` on the trigger, native `<dialog id="dialog-id" class="nq-dialog">`, and `data-close="dialog-id"` on the closing button. Supply `aria-labelledby`; Escape and focus containment stay native, focus returns to the trigger.
- Tooltip: `.nq-tooltip-wrap`, focusable trigger with `aria-describedby`, `.nq-tooltip[role="tooltip"]` with a matching unique ID. Pointer/focus reveals supplementary help; Escape hides it.

`initNasaq(root?)` returns an idempotent cleanup function. Repeated calls on the same active root reuse its setup. Passing an HTMLElement confines actions to that subtree. During server rendering, calling without a DOM root returns a no-op. Product behavior—requests, billing, uploading, data persistence and AI generation—is your application's responsibility.

## Tokens and assets

```js
import { tokens, tokenNames, getToken, version } from '@nasaq/ui';
const duration = getToken('interaction.reveal.duration'); // {value:320, unit:'ms'}
const english = getToken('type-en.body-md');
// CommonJS: const { getToken } = require('@nasaq/ui');
```

`tokens` preserves the DTCG groups/references; `getToken` recursively resolves a typed token's value and rejects unknown names or cyclic references. TypeScript declarations include a union of all token paths. Resolved composite values are new objects; don't mutate the exported source token tree.

Subpath exports: `styles.css`, `tokens.json`, `components.json`, `components.en.json`, `patterns.json`, `patterns.en.json`, `icons/*.svg`, `icons/manifest.json`, `assets/*` and `package.json`. Component/pattern JSON contains reusable HTML, states and guidance, rather than executable templates.

In Vite, import an SVG as a URL:

```js
import searchUrl from '@nasaq/ui/icons/search.svg?url';
```

Use `<img src={searchUrl} alt="">` inside a labelled button. Other frameworks may handle SVG imports differently; copy the selected icons to your public assets when needed. Don't mirror nondirectional icons or the logo. Choose one icon family per surface.

Use semantic/component CSS variables, `.nq-type-*` styles and motion roles. `lang` + `dir` scopes select `type.*` for Arabic or `type-en.*` for English; both modes support light/dark via `data-theme="dark"`. Use logical layout and `bdi` for mixed content. Native interaction helpers do not apply a theme or rewrite your content.

## Develop and publish

From the complete Nasaq workspace, run `python3 scripts/build.py` to regenerate the package from canonical tokens, CSS, fonts and catalogs. Run `node --test packages/ui/test/*.test.cjs` and `python3 scripts/verify.py` before publishing. The tarball is built with lifecycle scripts disabled and no registry upload.

Publish only after confirming scope ownership and the package version: `npm publish ./dist/downloads/nasaq-ui-1.3.0.tgz --access public`. The local build never publishes automatically.

Original package code/assets: MIT. Inter and Almarai: SIL OFL. Lucide/Feather: their supplied ISC/MIT notices. Keep LICENSE and THIRD_PARTY_NOTICES.md with redistributed assets.
