# Third-party assets

- Almarai (300, 400, 700, 800): SIL Open Font License 1.1. Full notice: assets/almarai-OFL.txt. Source: https://fonts.google.com/specimen/Almarai
- Inter variable font: SIL Open Font License 1.1. Full notice: assets/inter-OFL.txt. Source: https://github.com/google/fonts/tree/main/ofl/inter
- Lucide Static 1.52.0: ISC with applicable MIT notices for Feather-derived icons. Full notices: assets/lucide/LICENSE. Source: https://lucide.dev/license

Nasaq's code and original assets use the root MIT license. Keep all these notices when redistributing. This package does not include Thmanyah's branding or proprietary assets.
